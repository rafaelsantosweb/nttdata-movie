/**
 * @file
 * nttdata behaviors.
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.nttdata = {
    attach: function (context, settings) {

      console.log('It works!');

    }
  };

} (Drupal));
;
